import { testeType } from "./testeType"

export const schemaTypes = [testeType]
